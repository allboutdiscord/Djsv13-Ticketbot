module.exports = {
  prefix: "!",
  status: {
    		name: "Tickets!",
    		type: "watching"
  },
   emojis: {
        giveaway: "🎉",
        special: "🔴",
        general: "✅"
  },
  ticketembed: {
    title: "Tickets",
    description: "To create a ticket, click the button that suits your request!",
    footer: "By AllBoutDiscord"
  },
};